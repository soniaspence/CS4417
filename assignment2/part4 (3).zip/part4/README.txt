To run this program:

python3 mapper1.py path| sort -k1,1 | python3 reducer1.py | python3 mapper2.py | sort -k1,1 | python3 reducer2t.py | python3 mapper3.py | sort -k1,1 | python3 reducer3.py

make the path the path to the directory the code is finding the files in