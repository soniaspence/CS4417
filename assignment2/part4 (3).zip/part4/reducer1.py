# Sonia Spence
# Sunday March 20 2022
# CS 4417 Assignment 2

#!/usr/bin/env python
"""reducer.py"""

from operator import itemgetter
import sys

#set up place holders for comparing values
current_word = None
current_count = 0
word = None

# input comes from STDIN
for line in sys.stdin:
    # remove leading and trailing whitespace
    if line:
        line = line.split()
        word, doc, count = line


    # change count from string to integer
    try:
        count = int(count)
    except ValueError:
        #if count is not a number it is an invalid dataset so dispose of it accordingly
        continue

    # if the word occurs more than once adjust count
    if current_word == word and current_doc == doc:
        current_count += count

    # print line and change count to string
    else:
        if current_word:
            print_count = str(current_count)
            # changed this from og
            print ('%s\t%s\t%s' % (current_word, current_doc, current_count))
        current_count = count
        current_word = word
        current_doc = doc

#print last line
if current_word == word:
    print_count = str(current_count)
    # changed this from og
    print ('%s\t%s\t%s' % (current_word, current_doc, current_count))
