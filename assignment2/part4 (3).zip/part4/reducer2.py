# Sonia Spence
# Sunday March 20 2022
# CS 4417 Assignment 2

#!/usr/bin/env python
"""reducer.py"""

from operator import itemgetter
import sys

current_word = None
current_count = 0
word = None
df = 0
original_list = []
df_dict = {}


# input comes from STDIN through pipe
for line in sys.stdin:
    # remove leading and trailing whitespace
    if line:
        line = line.split()
        word, doc, count = line
        # put original values in list to retain info
        original_list.append(line)

    # change count from string to integer
    try:
        count = int(count)
    except ValueError:
        #if count is not a number it is an invalid dataset so dispose of it acc$
        continue

    # if the word occurs in multiple documents add 1 to the df
    if current_word == word:
        if word in df_dict:
            df_count = df_dict[word]
            df_count += 1
            df_dict[word] = df_count
    
    else:
        df_dict[word] = 1
    current_word = word

# use dictionary to find df value depending on word then print the appropriate values
for elem in original_list:
    search_word = elem[0]
    df = df_dict[search_word]
    print('%s\t%s\t%s\t%s' % (elem[0], elem[1], elem[2], df))
