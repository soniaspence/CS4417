# Sonia Spence
# Sunday March 20 2022
# CS 4417 Assignment 2

#!/usr/bin/env python
"""mapper3.py"""

from operator import itemgetter
import sys

# input comes from STDIN through pipe
for line in sys.stdin:
    if line:
        line = line.strip()
        line = line.split()
        word, doc, count, df = line
        print ('%s\t%s\t%s\t%s' % (word, doc, count, df))

