# Sonia Spence
# Sunday March 20 2022
# CS 4417 Assignment 2

import os
import errno
from pathlib import Path

#!/usr/bin/env python
"""mapper.py"""

import sys
import glob

#args for path input and list for multiple files
path = sys.argv
file_list = list()

#find files in directory
directory_name = glob.glob(path[1]+"/*")
for file in directory_name:
   file_list.append(file)

#for each file open and map the values
for file in file_list:
    fp = open(file)
    for line in fp:
        file_name = Path(file).stem
        line = line.strip()
        words = line.split()
        for word in words:
            print ('%s\t%s\t%s' % (word, file_name, 1))
