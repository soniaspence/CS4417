# Sonia Spence
# Sunday March 20 2022
# CS 4417 Assignment 2

#!/usr/bin/env python
"""reducer.py"""

from cmath import log10
from operator import itemgetter
import sys

# initialize variables
current_word = None
current_count = 0
word = None
doc_list = []
num_docs = 0
word_count = 0
original_list = []

# input comes from STDIN through pipe
for line in sys.stdin:
    # remove leading and trailing whitespace
    if line:
        line = line.split()
        word, doc, count, df = line
        original_list.append(line)

    try:
        count = int(count)
    
    except ValueError:
        #if count is not a number it is an invalid dataset so dispose of it accordingly
        continue

    # count the number on docs by putting them in a list and checking for matches
    if doc not in doc_list:
        doc_list.append(doc)
        num_docs += 1
    
    if word:
        word_count += count

# for each element in the orginal list calculate the TF-IDF
for elem in original_list:
    usable_tf = float(elem[2])
    tf_div_n = usable_tf / word_count
    usable_df = float(elem[3])
    num_div_df = num_docs / usable_df
    logged_df = log10(num_div_df)
    tf_idf = tf_div_n * num_div_df
    print_tf_idf = str(tf_idf)
    print('((%s, %s), (%s, %s, %s))' % (elem[1], elem[0], elem[2], elem[3], print_tf_idf))
