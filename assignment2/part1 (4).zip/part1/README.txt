To run this program:

python3 mapper.py path | sort -k1,1 | python3 reducer.py

make the path the path to the directory the code is finding the files in