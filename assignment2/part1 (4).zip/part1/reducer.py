# Sonia Spence
# Sunday March 20 2022
# CS 4417 Assignment 2

#!/usr/bin/env python
"""reducer.py"""

from operator import itemgetter
import sys

# set up counters to compare lines in docs
current_word = None
current_count = 0
word = None

# input comes from pipe
for line in sys.stdin:
    # remove leading and trailing whitespace
    if line:
        line = line.split()
        word, doc, count = line


    # change count from string to integer
    try:
        count = int(count)
    # ignore if not a number
    except ValueError:
        continue

    #if the word occurs more than once add to count
    if current_word == word and current_doc == doc:
        current_count += count
    else:
        # if there is a word print the line and set next current value
        if current_word:
            print_count = str(current_count)
            print('(' + current_word + ', ' + current_doc + '), ' + print_count + (')'))
        current_count = count
        current_word = word
        current_doc = doc

# if last print the line
if current_word == word:
    print_count = str(current_count)
    print('(' + current_word + ', ' + current_doc + '), ' + print_count + (')'))
